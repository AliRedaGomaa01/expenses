import{j as e}from"./app-DnSvRd9o.js";function s({message:r,className:t="",...n}){return r?e.jsx("p",{...n,className:"text-sm text-red-600 "+t,children:r}):null}export{s as I};
